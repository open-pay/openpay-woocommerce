=== Openpay Stores Plugin ===
Contributors: openpay
Tags: payment gateway, openpay, woocommerce
Requires at least: 4.8
Tested up to: 5.0.3
Requires PHP: 5.6
Stable tag: 1.4.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides a cash payment method with Openpay for WooCommerce

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html
