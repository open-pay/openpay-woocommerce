=== Openpay Stores Plugin ===
Contributors: openpay
Tags: payments, payment gateway, openpay, woocommerce
Requires at least: 4.8.0
Tested up to: 5.5
Requires PHP: 5.6
Stable tag: 1.9.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides a cash payment method with Openpay for WooCommerce.
== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html

== Changelog ==
= 1.9.0 =
* Enhancement. Unificación del plugin para procesar pagos México/Colombia
= 1.8.0 =
* Se actualiza el sdk PHP para dirigir a los servicios de Colombia. 
= 1.7.0 =
* Enhancement. Notificación para pagos vencidos, el estatus de la orden es cambiado a cancelado
= 1.6.0 =
* Enhancement. Se agregó la etiqueta User-Agent para identificar las transacciones del plugin
= 1.4.5 =
Fix. Evita conflicto del filtro woocommerce_email_attachments con otros plugins

== Upgrade Notice ==
Mejoras menores