=== Openpay Codi Plugin ===
Contributors: openpay
Tags: payment gateway, openpay
Requires at least: 4.8
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.1.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides a credit card payment method with Openpay for WooCommerce.

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html

== Changelog ==
= 1.1.0 =
* Cambio de imagen Openpay (Rebranding)
= 1.0.0 =
* Plugin created to accept payments via CoDi®

== Screenshots ==
1.- 
2.- 
3.- 