<?php
/*
  Title:	Openpay Payment extension for WooCommerce
  Author:	Openpay
  URL:		http://www.openpay.mx
  License: GNU General Public License v3.0
  License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
?>
<style>
    .payment_box.payment_method_openpay_checkout_lending{
        background-color: #F5F7F9 !important;
    }
</style>
<div class="row" id="steps-container">
    <div class="col-md-12" style="margin-top: 20px; margin-bottom: 10px; text-align:center; margin:0;">
        <img alt="Kueskipay" src="<?php echo $this->images_dir ?>kueski.png" style="display: inline; height: auto; float: none; max-height: none;" />
    </div>
</div>