=== Openpay Checkout Lending ===
Contributors: openpay
Tags: payment gateway, openpay, checkout, lending, kueski
Requires at least: 4.8
Tested up to: 6.4.3
Requires PHP: 5.6
Stable tag: 1.3.1
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides a lending payment method with Openpay for WooCommerce.

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html

== Changelog ==
= 1.3.1 =
* Actualización de logos Kueskipay
= 1.3.0 =
* Actualización de compatibilidad con Wordpress 6.4.3 & WooCommerce 8.5.2
= 1.2.1 =
* Actualización de certificado.
= 1.2.0 =
* Actualización php 8.1.16 y WP 6.3
= 1.1.1 =
* Mantenimiento y actualización de código.
= 1.1.0 =
* Cambio de imagen Openpay (Rebranding).
= 1.0.0 =
* Plugin created to accept payments via Checkout Lending.