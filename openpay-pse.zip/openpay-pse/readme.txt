=== Openpay PSE Plugin ===
Contributors: openpay
Tags: payments, payment gateway, openpay, woocommerce
Requires at least: 4.8
Tested up to: 5.7
Requires PHP: 5.6
Stable tag: 1.4.0
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides an electronic funds transfer payment method with Openpay for WooCommerce.

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html

== Changelog ==
= 1.4.0 =
* Implementación de Webhooks para notificaciones de pago.
= 1.3.0 =
* Se actualiza endpoint para cargos PSE Colombia
= 1.2.1 =
Fix. Envió de código de país al obtener la instancia Openpay
= 1.2.0 =
* Se actualiza el sdk PHP para dirigir a los servicios de Colombia. 
= 1.1.1 =
Fix. Corrección de logo PSE
1.1.0
Enhancement. Se agregó la etiqueta User-Agent para identificar las transacciones del plugin

== Upgrade Notice ==
Mejoras menores