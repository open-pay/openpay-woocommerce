<?php
/*
  Title:	Openpay Payment extension for WooCommerce
  Author:	Openpay
  URL:		http://www.openpay.mx
  License: GNU General Public License v3.0
  License URI: http://www.gnu.org/licenses/gpl-3.0.html
 */
?>
<div class="row">
    <div class="col-md-4" style="text-align: center;">
        <img src="<?php echo $this->images_dir ?>logo_pse.png" style="width: 100px; height: 100px; max-height: 100px;">        
    </div>    
</div>
<div style="height: 1px; clear: both; border-bottom: 1px solid #CCC; margin: 10px 0 10px 0;"></div>
<div style="text-align: center;">
    <img alt="" src="<?php echo $this->images_dir ?>openpay.png">	
</div>