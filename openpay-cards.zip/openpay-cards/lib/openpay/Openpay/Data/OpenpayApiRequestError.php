<?php

namespace Openpay\Data;

class OpenpayApiRequestError extends OpenpayApiError
{

}
