<?php

namespace Openpay\Resources;

use Openpay\Data\OpenpayApiDerivedResource;

class OpenpayCardList extends OpenpayApiDerivedResource
{

}
