<?php

namespace Openpay\Resources;

use Openpay\Data\OpenpayApiDerivedResource;

class OpenpayCustomerList extends OpenpayApiDerivedResource
{

}
