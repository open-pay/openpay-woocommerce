=== Openpay Cards Plugin ===
Contributors: openpay
Tags: payment gateway, openpay
Requires at least: 4.8
Tested up to: 4.9.5
Requires PHP: 5.6
Stable tag: 1.3.1
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html

Provides a Credit Card Payment Gateway through Openpay for WooCommerce.

== Installation ==
For more information about this module go to: 

http://www.openpay.mx/docs/plugins/woocommerce.html

== Screenshots ==
1. https://www.openpay.mx/img/plugins/woocommerce_config_03.png
2. https://www.openpay.mx/img/plugins/woocommerce_config_04.png
3. https://www.openpay.mx/img/plugins/woocommerce_config_06.png